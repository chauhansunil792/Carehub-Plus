<?php 

class About extends CI_Controller{
	public function index(){
		$this->load->view('user/about_view');
	}
}

?>